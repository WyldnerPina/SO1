package view;

import model.Lista;

public class Principal {

	public static void main(String[] args) {
		Lista lista = new Lista();
		try {
			lista.addFirst(1);
			lista.addLast(2);
			lista.add(10, 1);
			lista.addFirst(0);
			lista.add(20, 2);
			System.out.println(lista.get(0));
			System.out.println(lista.get(2));
			lista.removeFirst();
			lista.removeLast();
			lista.remove(1);
			System.out.println(lista.get(0));
			
			int tamanho = lista.size();
			System.out.println("Tamanho da lista = " + tamanho);
			System.out.println(lista.get(tamanho -1));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
