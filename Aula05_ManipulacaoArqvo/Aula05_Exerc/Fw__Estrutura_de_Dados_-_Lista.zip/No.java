package model;

public class No {
	
	int dado;
	No proximo;
	
	public String toString() {
		return "No [dado " + dado + "]";
	}

}
